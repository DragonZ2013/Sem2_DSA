#include "Map.h"
#include "MapIterator.h"
#include <exception>
using namespace std;


MapIterator::MapIterator(const Map& d) : map(d)
{
	if (this->map.nrElems == 0)
		throw exception();
	this->index = 0;
}


void MapIterator::first() {
	if (this->map.nrElems == 0)
		throw exception();
	this->index = 0;
}


void MapIterator::next() {
	if (this->valid() == false)
		throw exception();
	this->index++;
}


TElem MapIterator::getCurrent(){
	if (this->valid() == false)
		throw exception();
	return this->map.elements[this->index];
}


bool MapIterator::valid() const {
	if (this->index < this->map.nrElems)
		return true;
	return false;
}



