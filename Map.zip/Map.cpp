#include "Map.h"
#include "MapIterator.h"

Map::Map() {
	//TODO - Implementation
	this->cap = 4;
	this->nrElems = 0;
	this->elements = new TElem[cap];
}

Map::~Map() {
	//TODO - Implementation
	delete[] this->elements;
}

TValue Map::add(TKey c, TValue v){
	//TODO - Implementation
	TValue value = this->search(c);  // returns the value associated with the key if the map contains the key or null
	if (value == NULL_TVALUE)
	{
		if (this->nrElems == this->cap)
		{
			this->cap = 2 * this->cap;
			TElem* newelements = new TElem[cap];
			for (int i = 0; i < this->nrElems; i++)
				newelements[i] = this->elements[i];	
			delete[] this->elements;
			this->elements = newelements;
		}
		TElem newpair(c, v);
		this->elements[this->nrElems] = newpair;
		this->nrElems++;
		return NULL_TVALUE;
	}
	else
	{
		for (int i = 0; i < this->nrElems; i++)
			if (this->elements[i].first == c)
			{
				this->elements[i].second = v;
				return value;
			}
	}
}

TValue Map::search(TKey c) const{
	//TODO - Implementation
	for (int i = 0; i < this->nrElems; i++)
		if (this->elements[i].first == c)
			return this->elements[i].second;
	return NULL_TVALUE;
}

TValue Map::remove(TKey c){
	//TODO - Implementation
	TValue value = this->search(c);
	int index;
	if (value == NULL_TVALUE)
		return NULL_TVALUE;
	else
	{
		for (int i = 0; i < this->nrElems; i++)
			if (this->elements[i].first == c)
			{
				index = i;
				break;
			}
		for (int i = index + 1; i < this->nrElems; i++)
			this->elements[i - 1] = this->elements[i];
		this->nrElems--;
		return value;
	}
}


int Map::size() const {
	//TODO - Implementation
	return this->nrElems;
}

bool Map::isEmpty() const{
	//TODO - Implementation
	if (this->nrElems == 0)
		return true;
	return false;
}

MapIterator Map::iterator() const {
	return MapIterator(*this);
}



