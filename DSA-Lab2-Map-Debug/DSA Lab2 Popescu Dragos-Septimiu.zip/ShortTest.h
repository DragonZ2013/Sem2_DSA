#pragma once

void testAll();
void testFunc();
