#pragma once
#include <assert.h>

void testAll();
